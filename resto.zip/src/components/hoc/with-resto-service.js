import React from 'react';
import RestoServiceContext from '../resto-service-context';

const WithRestoService = () => () => {
    return 1;
};

export default WithRestoService;