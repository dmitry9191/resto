import Error from './error';

export default Error;